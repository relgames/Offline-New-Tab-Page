The icon for "Offline New Tab Page" is taken from
[http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org/Actions-tab-close-icon.html]
under the GNU Lesser General Public License.